#!/bin/env python3

import requests
from bs4 import BeautifulSoup

token = "eyJfcmFpbHMiOnsibWVzc2FnZSI6IlcxczBOemN5TVRWZExDSmxNMU5OZW1OcFZHNTRhRGg2TXpGNk5qWnpSaUlzSWpFM01qVTNPVFExTURJdU1EVTVNemcxT0NKZCIsImV4cCI6IjIwMjQtMDktMjJUMTE6MjE6NDIuMDU5WiIsInB1ciI6ImNvb2tpZS5yZW1lbWJlcl91c2VyX3Rva2VuIn19--1a252c84f5d9c76e12f7798222e5bcc55a75450e"

session = "7iH8Y8s6Rx4v5heC2azL%2B%2BzRgY3qlIL9hRJB1gFz7DgISVIiI%2FR2P7cdRB34kuJMANuMsqsxsopfKH5We1PNC0OQC%2B4u3iXVxN6hnirTyCG8Y9ImuXA0gVOunrqjo70x6qh%2FYgumswowGCcy8LrigyQBpqN4fBPVPGEgAj%2Fv0ez0rYkkmr0gitsAPIUjehVSRx9LnxD7BmRIq3id%2BH0IES%2FKFuuUQdxLzAS9PP3TwNc8%2BtBLL5NefxAOAtLRoc7a615HvGTXM2FX5kd1lHkIumVFq0AaMOtlrvKHK5ftGQwPqGnBDbo1BE8IMWLOxY9wTsa0bp6FC7XRBKWjhGE7unSTqrQFlMTmz5j2yn7%2BocqcXeOxtccG6q3Nk9ZD%2F1a5ak2bHmTliJ6eZmwQU%2BNqK4yZ36oNsFid9WCVcSwtjWkrroOzSwXynyYD%2FZomi9B6Plrk%2FWSUctIdboJr9ta5qIW8YG6q4pw%3D--p5Wn89q79RT4aK3S--hCbEkG%2Bn4xQgCHUdDrvYug%3D%3D"

curriculum_id = "eyJfcmFpbHMiOnsibWVzc2FnZSI6Ik1RPT0iLCJleHAiOm51bGwsInB1ciI6ImNvb2tpZS5jb250ZXh0X2N1cnJpY3VsdW1faWQifX0%3D--13a16f95b6e3ae5baf1d5fad5b62fd25b7316e16"

cookies = { "token": token, "_holberton_intranet_session":session, "context_curriculum_id": curriculum_id}

headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-language': 'en-US,en;q=0.7',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Chromium";v="128", "Not;A=Brand";v="24", "Brave";v="128"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
        }


class Alxer:
    root = "https://intranet.alxswe.com"
    base_url = 'https://intranet.alxswe.com/projects/{}'
    temp_file = "temp.html"
    base_concept_url = "https://intranet.alxswe.com/concepts/{}"
    def get_html(self, _id):
        """Download the html project using its id and store it in the temp.html
        WARN: this will do an actual request to the server
        """
        url = self.base_url.format(_id)
        r = requests.get(url, cookies=cookies, headers=headers)
        if (r.status_code == 404):
            print("Project with the id {} not found".format(_id))
            exit(1)
        html = r.text
        with open(self.temp_file, "w") as f:
            file = f.write(html)

    def get_concept_html(self, _id):
        """Download the html concept using its id and store it in the temp.html
        WARN: this will do an actual request to the server
        """
        print("Downloading the concept N° {}...".format(_id))
        url = self.base_concept_url.format(_id)
        r = requests.get(url, cookies=cookies, headers=headers)
        if (r.status_code == 404):
            print("Concepts with the id {} not found".format(_id))
            exit(1)
        html = r.text
        soup = BeautifulSoup(html, 'html.parser')
        file_name = "concept_{}.html".format(_id)
        file_path = "projects/concepts/{}".format(file_name)
        self.add_style(soup, "..")
        self.replace_Tokenized_links(soup)
        self.fix_img_link(soup)
        with open(file_path, "w") as f:
            f.write(str(soup))
        return file_name

    def fix_img_link(self, soup):
        """Adding the root to src link"""
        for img in soup.find_all('img'):
            if type(img.get('src')) is str and 'images' in img.get('src'):
                img["src"] = self.root + img["src"]

    def replace_Tokenized_links(self, soup):
        """Will change every link that has token in it and replace it with the
        redirected link
        """
        for link in soup.find_all('a'):
            if type(link.get('href')) is str and 'token' in link.get('href'):
                label = link.contents[0]
                protected_href = self.root + link.get('href')
                link["href"] = self.get_redirected_url(protected_href)

    def follow_links(self):
        """Change every link that's need authontication"""
        with open(self.temp_file, "r") as f:
            html = f.read()
        soup = BeautifulSoup(html, 'html.parser')
        file_name = soup.h1.contents[0].strip().replace(" ", "_").replace("/", "_").replace(":", "_") + ".html"
        for link in soup.find_all('a'):
            if type(link.get('href')) is str and 'token' in link.get('href'):
                label = link.contents[0]
                protected_href = self.root + link.get('href')
                link["href"] = self.get_redirected_url(protected_href)
            if type(link.get('href')) is str and 'concepts/' in link.get('href'):
                _id = link.get('href').split("/")[-1]
                link["href"] = "concepts/" + self.get_concept_html(_id)
        self.add_style(soup)
        with open("projects/{}".format(file_name), "w") as f:
             f.write(str(soup))
        print("File stored in:")
        print("projects/{}".format(file_name))


    def add_style(self, soup, styles_path="."):
        """Add the link to css files in head element"""
        head_tag = soup.head
        link_tag = soup.new_tag('link', rel="stylesheet", media="screen",
                                href="{}/styles/style.css".format(styles_path))
        head_tag.append(link_tag)
        body_tag = soup.body
        body_tag['class'].append('dark')

    def save_project(self, _id):
        """Download the html and replace protected url and save it in the
        projects directory
        """
        download = input("""This will download the html and follow every link in the project, are you sure? y/*""")
        if download != 'y':
            print("Ok! nothing will be done :)")
            exit()
        print("Downloading the html...")
        self.get_html(_id)
        print("Replacing urls...")
        self.follow_links()

    def get_redirected_url(self, url):
        """Send a HEAD_ request instead of GET to avoid downloading the whole
        page
        WARN: this will do an actual request to the server
        """
        print("GET ", url)
        try:
            response = requests.head(url, allow_redirects=True, cookies=cookies, headers=headers)
            print(response.url)
            return response.url
        except requests.RequestException as e:
            print(f"An error occurred in url :{url} \n{e}")
            return None


if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: {} <project_id>".format(sys.argv[0]))
        exit(1)
    if not sys.argv[1].isdigit():
        print("Usage: {} <project_id>".format(sys.argv[0]))
        print("       {} ^^^^^^^^^^^^  <- Must be a number :(".format(' '*len(sys.argv[0])))
        exit(1)

    a = Alxer()
    a.save_project(sys.argv[1])
